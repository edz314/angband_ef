#ifndef DS_IPC_H
#define DS_IPC_H

#define IPC_SHUTDOWN FIFO_USER_01
#define IPC_NDS_TYPE FIFO_USER_02

#endif
