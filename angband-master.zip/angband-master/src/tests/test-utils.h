/* test-utils.h 
 *
 * Function prototypes for test-utils
 *
 * Created by: myshkin
 *             26 Apr 2011
 */

#ifndef TEST_UTILS_H
#define TEST_UTILS_H

void set_file_paths(void);
void read_edit_files(void);

#endif /* TEST_UTIL_H */
