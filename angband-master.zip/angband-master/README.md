# Angband 4.2.0


Angband is a graphical dungeon adventure game that uses textual characters
to represent the walls and floors of a dungeon and the inhabitants therein, 
in the vein of games like NetHack and Rogue.  If you need help in-game,
press '?'.

### More Information:

1. For more information, somewhere to upload your characters and screenshots, and discuss the game, try [Angband Website](http://angband.oook.cz/).

2. If you're compiling the game yourself, read [this page on compiling](https://angband.readthedocs.io/en/latest/hacking/compiling.html.)


Enjoy!

-- The Angband Dev Team
